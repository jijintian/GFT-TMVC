function [G, objV] = solve_G_fun_data_driven(x, miu, sX, yita,fun)
% solve min 1/miu ||G||_gamma + 1/2||G-(Z+W/MIU)||_F^2
% 使用数据驱动的酉变换 (Data-Driven Unitary Transform) 代替 FFT

er = 0.0001;
    G_hat = reshape(x, sX);
    
    % 1. 调整维度，确保 Mode-3 是样本维度
    % 假设 G_hat 原本是 d x v x n
    % shiftdim(G_hat, 1) 后变为 v x n x d ? 
    % 请务必确认这里 G_hat_re 的第3维是你想要变换的样本维度
    G_hat_re = shiftdim(G_hat, 1);
    
    [n1, n2, n3] = size(G_hat_re); % n3 是样本数
    
    %% 2. 学习变换矩阵 U (Data-Driven Step)
    % 展开矩阵: n3 x (n1*n2)
    Unfolding = reshape(permute(G_hat_re, [3, 1, 2]), n3, []); 
    
    % SVD: U 的大小可能是 (n3 x n3) 也可能是 (n3 x n1*n2)
    [U, ~, ~] = svd(Unfolding, 'econ');
    

   
    % 获取变换后的新维度 K (如果是方阵 K=n3，如果是长方形 K < n3)
    transform_dim = size(U, 2); 
    
    %% 3. 前向变换 (Forward Transform)
    % (K x n3) * (n3 x M) -> K x M
    G_transformed_mat = U' * Unfolding;
    
    % === 修正点：使用动态的 transform_dim 而不是 n3 ===
    % Reshape: K, n1, n2
    G_hat_trans = permute(reshape(G_transformed_mat, transform_dim, n1, n2), [2, 3, 1]);
    % 现在 G_hat_trans 的大小是 n1 x n2 x transform_dim
    
    %% 4. 在变换域逐切片求解
    G_hat_processed = zeros(size(G_hat_trans));
    objV = 0;
    max_iter = 100;

    % 遍历新的维度 transform_dim (可能等于 n3，也可能小于 n3)
    for i = 1:transform_dim
        slice = G_hat_trans(:,:,i);
        
        [uhat, shat, vhat] = svd(slice, 'econ');
        sigma = diag(shat);
        sigma_i = sigma;
        
        % 迭代阈值求解
        for j = 1:max_iter
            w_i = rank_fun_derivative(sigma_i,yita,fun);
            sigma_i1 = max(0, sigma - w_i/miu);
            
            if sum((sigma_i1 - sigma_i).^2) < er
                break
            end
            sigma_i = sigma_i1;
        end
        
        shat_new = diag(sigma_i1);
        objV = objV + sum(shat_new(:));
        G_hat_processed(:,:,i) = uhat * shat_new * vhat';
    end

    %% 5. 逆变换 (Inverse Transform)
    % 先展开: K x (n1*n2)
    Unfolding_processed = reshape(permute(G_hat_processed, [3, 1, 2]), transform_dim, []);
    
    % 乘回 U: (n3 x K) * (K x M) -> n3 x M
    % 这一步会自动把维度从 transform_dim 恢复回 n3
    G_recon_mat = U * Unfolding_processed;
    
    % 还原张量形状: n3, n1, n2 -> Permute -> n1, n2, n3
    G_recon = permute(reshape(G_recon_mat, n3, n1, n2), [2, 3, 1]);
    
    %% 6. 恢复原始输入维度顺序
    G = shiftdim(G_recon, 2);
end
