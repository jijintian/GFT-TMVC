clc;
clear;
addpath('./');
addpath('./measure');
addpath('..\dataset_shuffle');

% Define the list of datasets
dataname = ["MSRCv1"];
num_runs = 5; 

for it_name = 1:length(dataname)
    fprintf('Processing dataset: %s\n', dataname(it_name));
    
    load(strcat('dataset_shuffle/Shuffle_', dataname(it_name), '.mat'));
    X_raw = data; 
    gt_raw = double(gt);
    N = size(X_raw{1}, 2);
    cls_num = length(unique(gt_raw));
    num_views = length(X_raw);

    run_results = []; 
    run_times = zeros(num_runs, 1);
    run_paras = zeros(num_runs, 1);

    for run = 1:num_runs
        fprintf('--- Random run %d/%d ---\n', run, num_runs);
        
        %%
        rand_index = randperm(N);
        gt = gt_raw(rand_index);
        X = cell(size(X_raw));
        for v = 1:num_views
            X{v} = X_raw{v}(:, rand_index);
            X{v} = NormalizeData(X{v}); 
        end

        %%
        max_val = 0;
        best_result_this_run = [];
        best_para_this_run = 0;
        best_time_this_run = 0;

        lambda_base = 0.0001;
        for i = 1:9
            current_lambda = lambda_base * i;
            
            tic;
            [Z, E] = TLS_pNMMSC(X, current_lambda);

            S = 0;
            for k = 1:num_views
                S = S + abs(Z{k}) + abs(Z{k}');
            end
            
            C = SpectralClustering(S, cls_num);
            current_time = toc;
            
            result = ClusteringMeasure1(gt, C)
            
            if result(1) > max_val
                max_val = result(1);
                best_result_this_run = result;
                best_para_this_run = i;
                best_time_this_run = current_time;
            end
        end
        
        run_results = [run_results; best_result_this_run];
        run_times(run) = best_time_this_run;
        run_paras(run) = best_para_this_run;
    end

    %%
    final_mean = mean(run_results, 1);
    final_std = std(run_results, 0, 1);
    avg_time = mean(run_times);

        fprintf('\nDataset %s: mean ACC over %d runs: %.4f ± %.4f\n', ...
        dataname(it_name), num_runs, final_mean(1), final_std(1));

    %%
    save_filename = fullfile('result', strcat('Final_fft_', dataname(it_name), '.mat'));
    save(save_filename, 'run_results', 'final_mean', 'final_std', 'run_times',  'avg_time');
end