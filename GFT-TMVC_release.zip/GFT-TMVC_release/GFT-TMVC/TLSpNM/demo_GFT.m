clc;
clear;
addpath(genpath('./'));
addpath('./');
addpath('./measure');
addpath('..\dataset_shuffle');

% Define the list of datasets
dataname = ["MSRCv1"];
num_runs = 5; 
W_types = ["GFT","GMC","AGFT","Ideal"];
for it_name = 1:length(dataname)
    for i_w = 1:length(W_types)
        W_type = W_types(i_w);
        
        fprintf('\nProcessing dataset: %s, weight type: %s\n', dataname(it_name), W_type);
        
        load(strcat('dataset_shuffle/Shuffle_', dataname(it_name), '.mat'));
        
        run_results = zeros(num_runs, 7);
        run_times = zeros(num_runs, 1);
        
        for r = 1:num_runs
            fprintf('  Starting random run %d/%d...\n', r, num_runs);
            
            X = data;
            gt_orig = double(gt);
            cls_num = length(unique(gt_orig));
            num_views = length(X);
            N = size(X{1}, 2);
            
            %%
            rand_index = randperm(N);
            gt_curr = gt_orig(rand_index);
            X_curr = cell(1, num_views);
            X1 = cell(1, num_views);
            
            for v = 1:num_views
                X_curr{v} = X{v}(:, rand_index); 
                X_curr{v} = NormalizeData(X_curr{v});
                X1{v} = X_curr{v}'; 
            end
            
      
            [V_base] = compute_V_base(X1, W_type, gt_curr);
            
            %%
            max_val_in_run = -1;
            best_re_in_run = [];
            best_time_in_run = 0;
            
            base_lambda = 0.0001;
            for p = 1:9
                tic;
                lambda = base_lambda * p;
                
                [Z, E] = TLS_pNMMSC_GFT_V(X_curr, lambda, V_base);
                
                S = 0;
                for k = 1:num_views
                    S = S + abs(Z{k}) + abs(Z{k}');
                end
                C = SpectralClustering(S, cls_num);
                t_spent = toc;
                
                result = ClusteringMeasure1(gt_curr, C)
                
                if result(1) > max_val_in_run
                    max_val_in_run = result(1);
                    best_re_in_run = result;
                    best_time_in_run = t_spent;
                end
            end
            
            run_results(r, :) = best_re_in_run;
            run_times(r) = best_time_in_run;
        end
        
        %%
        mean_re = mean(run_results, 1);
        std_re = std(run_results, 0, 1);
        mean_time = mean(run_times);
        std_time = std(run_times);
        fprintf('  [Done] Mean ACC over 5 runs: %.4f ± %.4f\n', mean_re(1), std_re(1));
        
        %%
        save_path = fullfile('result', strcat('Final_result_', W_type, '_', dataname(it_name), '.mat'));
        if ~exist('result', 'dir'), mkdir('result'); end
        
        save(save_path, 'run_results', 'mean_re', 'std_re', 'mean_time','run_times','std_time');
    end
end