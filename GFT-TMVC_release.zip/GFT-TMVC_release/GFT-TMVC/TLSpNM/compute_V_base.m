function [V_base] = compute_V_base(X_raw, W_type, Y)
% X: N*d matrix (Samples as rows)
% W_type: 'GFT',GMC, 'AGFT','SFMC' 'Ideal'
% Y: Label vector for 'Ideal' mode

if nargin < 3
    Y = 0;
end

for v = 1:length(X_raw)
    temp_X = X_raw{v};
    row_norm = sqrt(sum(temp_X.^2, 2));
    
    X1{v} = temp_X ./ (row_norm + eps);
end
X = cat(2, X1{:,:});
num_samples = size(X, 1);

if strcmp(W_type, 'GFT')
    options_V = [];
    options_V.NeighborMode = 'KNN';
    options_V.k = 10; %MSRCv1:14,default 10
    options_V.WeightMode = 'Binary';
    options_V.t = 1;
    W_V = constructW(X, options_V);
    
    d = sum(W_V, 2);
    d_inv_sqrt = 1 ./ sqrt(d + eps);
    D_inv_sqrt = diag(d_inv_sqrt);
    L = eye(num_samples) - D_inv_sqrt * W_V * D_inv_sqrt;
    L = (L + L') / 2;
    
    [V_base, D_val] = eig(full(L));
    %          V_base = V_all(:, ind);
    
elseif strcmp(W_type, 'AGFT')
    cls_num = length(unique(Y));
    if cls_num >10 , cls_num = 10; end 
    
    [AZ, ~] = AnchorGEN(X, cls_num-1, cls_num-1, 1); % MSRCv1:cls_num-1,other:cls_num
    d_col = sum(AZ, 1);
    AB = AZ * diag(1 ./ sqrt(d_col + eps));
    
    [V_all, SS, ~] = svd(AB, 'econ');
    s_values = diag(SS);
    
    idx = find(s_values > 0.5);%
    V_base = V_all(:, idx);
    
    
elseif strcmp(W_type, 'Ideal')
    num_samples = length(Y);
    W_I = double(repmat(Y(:), 1, num_samples) == repmat(Y(:)', num_samples, 1));
    W_I = W_I - eye(num_samples);
    
    d = sum(W_I, 2);
    d_inv_sqrt = 1 ./ sqrt(d + eps);
    D_inv_sqrt = diag(d_inv_sqrt);
    L_ideal = eye(num_samples) - D_inv_sqrt * W_I * D_inv_sqrt;
    
    [V_base, D_val] = eig(full(L_ideal));
    
elseif strcmp(W_type, 'GMC')
    [W,~] = GMC_Graph(X_raw,length(unique(Y)));
    W_G = (W+W')/2;
    d = sum(W_G, 2);
    d_inv_sqrt = 1 ./ sqrt(d + eps);
    D_inv_sqrt = diag(d_inv_sqrt);
    L = eye(num_samples) - D_inv_sqrt * W_G * D_inv_sqrt;
    L = (L + L') / 2;
    
    [V_base, D_val] = eig(full(L));
elseif strcmp(W_type, 'SFMC')
    cls_num = length(unique(Y));
    if cls_num >10 , cls_num = 10; end 
    
    anchor_rate=2^(cls_num)/length(Y);
    projev = 1.5;
    i = 1;
    c = length(unique(Y));
    opt1. style = 1;
    opt1. IterMax =50;
    opt1. toy = 0;
    [AZ, ~] = FastmultiCLR(X_raw, c, anchor_rate, opt1,10);
    d_col = sum(AZ, 1);
    AB = AZ * diag(1 ./ sqrt(d_col + eps));
    
    [V_all, SS, ~] = svd(AB, 'econ');
    s_values = diag(SS);
    
    idx = find(s_values > 0.5);
    V_base = V_all(:, idx);
end

end