function paretoSet = findParetoFront(data)

    numSolutions = size(data, 1);
    paretoSet = true(numSolutions, 1);  

    for i = 1:numSolutions
        if paretoSet(i)  
            for j = 1:numSolutions
                if i ~= j && all(data(j, :) <= data(i, :)) && any(data(j, :) < data(i, :))
                    paretoSet(i) = false;  
                    break;
                end
            end
        end
    end
end

