clear;
clc;
warning off;
addpath('..\dataset_shuffle');
addpath(genpath('./'));

dataname = ["MSRCv1"];
num_runs = 5; 

%% ==================== Dataset Loop ===================
for it_name = 1:length(dataname)
    fprintf('\nProcessing dataset: %s\n', dataname(it_name));
    
    % 加载原始数据
    load(strcat('dataset_shuffle/Shuffle_', dataname(it_name), '.mat'));
    % 备份原始数据，确保每轮 run 都是基于原始顺序重新打乱
    X_raw = data'; 
    gt_raw = gt;
    
    cls_num = length(unique(gt_raw));
    nV = length(X_raw);
    nN = length(gt_raw);
    
    % 存储 10 次 Run 的最终结果
    % 我们会记录每一轮 Run 中通过参数搜索得到的最优 ACC 指标组合
    all_runs_best_result = []; 
        run_times = zeros(num_runs, 1);
    %% ==================== 10 Runs Shuffle ===================
    for run = 1:num_runs
        fprintf('\n--- Run %d/%d ---\n', run, num_runs);
        % 1. 执行样本打乱 (Shuffle)
        rand_idx = randperm(nN);
        gt = gt_raw(rand_idx);
        X = cell(1, nV);
        for v = 1:nV
            X{v} = X_raw{v}(:,rand_idx); 
            [X{v}] = NormalizeData(X{v}); 
        end
        
        % 2. 参数设置与本轮寻优变量初始化
        max_val_run = 0;
        record_result_run = [];
        record_time_run = 0;
        
        anc = [2*cls_num, 3*cls_num, 4*cls_num, 5*cls_num, 6*cls_num, 7*cls_num, 8*cls_num];
        

        for i = -3:1:0
            for jj = -6:1:-3
                for j = -2:1:0
                    for k = 1: 6
                        alpha = 10^(i);
                        gamma = 10^(jj);
                        delta = 10^(j);
                        anchor = anc(k);
                        
                        tic;
                        [y, U, Z, converge_Z, converge_Z_G] = Train_problem_fft_view(X, cls_num, anchor, alpha, gamma, delta);
                        time = toc;
                        
                        [current_res, ~] = ClusteringMeasure(gt, y)
                        
            
                        if current_res(1) > max_val_run
                            max_val_run = current_res(1);
                            record_result_run = current_res;
                            record_time_run = time;
                        end
                    end
                end
            end
        end
        
        % 记录这一轮 Shuffle 实验得到的最佳表现
        all_runs_best_result = [all_runs_best_result; record_result_run];
        run_times(run) = record_time_run;
        fprintf('Run %d Best ACC: %.4f\n', run, max_val_run);
    end

    %% ==================== Statistics & Save ===================
    % 计算 10 次实验的均值和标准差
    mean_result = mean(all_runs_best_result, 1);
    std_result = std(all_runs_best_result, 0, 1);
    mean_time = mean(run_times);
    std_time = std(run_times);
    fprintf('\n>>>> FINAL SUMMARY for %s <<<<\n', dataname(it_name));
    fprintf('Mean: %.4f (ACC), %.4f (NMI), %.4f (Purity)\n', mean_result(1), mean_result(2), mean_result(3));
    
    % 创建保存路径
    if ~exist('result_fft', 'dir'), mkdir('result_fft'); end
    save_path = fullfile('result_fft', strcat('result_fft_view_runs_', dataname(it_name), '.mat'));
    
    save(save_path, 'all_runs_best_result', 'mean_result', 'std_result','mean_time','run_times',"std_time");
end