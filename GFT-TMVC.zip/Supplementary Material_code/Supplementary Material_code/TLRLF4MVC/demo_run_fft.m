clear all; 
close all; 
clc;
warning off;
addpath(genpath('./'));
% Add paths for datasets and utility functions
addpath('datasets','transform', 'Utility')
addpath('..\dataset_shuffle');

% Define the list of datasets
dataname = ["MSRCv1"];
num_runs = 5; % 设定随机次数

for it_name = 1:length(dataname)
    dataName = dataname(it_name);
    fprintf('\nProcessing Dataset: %s \n', dataName);
    
    % 加载原始数据（假设加载后变量名为 X 和 Y）
    % 注意：如果你的加载方式不同，请确保 X 是 cell, Y 是向量
    load(strcat('Shuffle_', dataName, '.mat')); 
    X_raw = data; % 备份原始数据
    Y_raw = gt;
    
    V = numel(X_raw);
    N = length(Y_raw);
    for v = 1:V
            X_raw{v} =X_raw{v}'; 
    end
    
    % 初始化存储 10 次实验最优结果的矩阵 (假设 Clustering8Measure 返回 8 个指标 + Time)
    all_runs_best = zeros(num_runs, 9); 

    for run = 1:num_runs
        fprintf('\n--- Run %d/%d ---\n', run, num_runs);
        
        %% 1. 数据打乱 (Shuffle)
        rand_idx = randperm(N);
        Y = Y_raw(rand_idx);
        X = cell(1, V);
        for v = 1:V
            X{v} = X_raw{v}(rand_idx,:); % 假设原始维度是 dim x num，若反之请修改
        end

        %% 2. 生成 GFT 变换矩阵 (根据打乱后的数据重新计算)
        if ~exist('transform', 'dir')
            cls_num = length(unique(Y));
            X1 = cell(1, V);
            for v = 1:V
                X1{v} = normalize(X{v}, 2); % 映射到样本行进行归一化
            end
            X_pre = cat(2, X1{:,:}); 
            pred_label = litekmeans(X_pre, cls_num, 'MaxIter', 1000, 'Replicates', 3);
            options = [];
            options.NeighborMode = 'Supervised';
            options.gnd = pred_label;
            options.WeightMode = 'Binary';
            options.t = 1;
            W = constructW(X_pre, options);
            [Fin, S] = eig(full(W));
            transform.L = Fin;
        else
            load(strcat(dataName, '_', 'transform.mat'));
        end

        %% 3. 非线性锚点嵌入 (Nonlinear Anchor Embedding)
        X_embed = cell(1, V);
        fprintf('Anchor Embedding View: ');
        for it = 1:V
            fprintf('%d ', it);
            if cls_num>10
            [~, Anchor_it] = AnchorGEN(X{it}, 10, cls_num, 1);%10,20
            else
                [~, Anchor_it] = AnchorGEN(X{it}, cls_num, cls_num, 1);%10,20
            end
            
            dist = EuDist2(X{it}, Anchor_it, 0); 
            sigma = mean(min(dist, [], 2).^0.5) * 2;
            feaVec = exp(-dist / (2 * sigma * sigma));
            X_embed{it} = bsxfun(@minus, feaVec', mean(feaVec', 2));
        end
        fprintf('\n');

        %% 4. 参数网格寻优
        Gamma = [1e-4, 1e-3, 1e-2, 1e-1, 1];
        Lambda = [1e-4, 1e-3, 1e-2, 1e-1, 1];
        Mu = [1e-4, 1e-3, 1e-2, 1e-1, 1];
        
        best_acc_this_run = -1;
        best_res_this_run = [];

        for i = 1:length(Lambda)
            for s = 1:length(Gamma)
                for k = 1:length(Mu)
                    paras.X = X_embed;
                    paras.lambda = Lambda(i);
                    paras.gamma = Gamma(s);
                    paras.mu = Mu(k);
                    paras.Y = Y;
                    paras.M = length(unique(Y));
                    paras.N = paras.M;

                    t_start = tic;
                    [pred_label] = TLRLF4MVC_Function(paras, transform);
                    t_time = toc(t_start);

                    Result = Clustering8Measure(Y, pred_label)
                    
                    % 记录当前随机状态下的最优 ACC 结果
                    if Result(1) > best_acc_this_run
                        best_acc_this_run = Result(1);
                        best_res_this_run = [t_time, Result];
                    end
                end
            end
        end
        all_runs_best(run, :) = best_res_this_run;
        fprintf('Run %d Best ACC: %5.4f\n', run, best_acc_this_run);
    end

    %% 5. 计算统计结果
    avg_res = mean(all_runs_best, 1);
    std_res = std(all_runs_best, 0, 1);

    fprintf('\n================== FINAL RESULT (%s) =====================\n', dataName);
    fprintf('Metric:   Time     ACC      NMI      Purity   Fscore   Prec     Recall   ARI      Entro\n');
    fprintf('Mean:     %5.4f   %5.4f   %5.4f   %5.4f   %5.4f   %5.4f   %5.4f   %5.4f   %5.4f\n', avg_res);
    fprintf('Std:      %5.4f   %5.4f   %5.4f   %5.4f   %5.4f   %5.4f   %5.4f   %5.4f   %5.4f\n', std_res);

    save(strcat('result\final_summary_fft_', dataName), 'all_runs_best', 'avg_res', 'std_res');
end

