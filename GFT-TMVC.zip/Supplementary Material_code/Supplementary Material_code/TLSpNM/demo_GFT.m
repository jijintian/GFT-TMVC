clc;
clear;
addpath(genpath('./'));
addpath('./');
addpath('./measure');
addpath('..\dataset_shuffle');

% Define the list of datasets
dataname = ["MSRCv1"];
num_runs = 5; % 设定随机实验次数
W_types = ["GFT","GMC","AGFT","Ideal"];
for it_name = 1:length(dataname)
    for i_w = 1:length(W_types)
        W_type = W_types(i_w);
        
        fprintf('\n正在处理数据集: %s, 权重类型: %s\n', dataname(it_name), W_type);
        
        % 加载数据（移出随机循环，减少IO开销）
        load(strcat('dataset_shuffle/Shuffle_', dataname(it_name), '.mat'));
        
        run_results = zeros(num_runs, 7);
        run_times = zeros(num_runs, 1);
        
        for r = 1:num_runs
            fprintf('  开始第 %d/%d 次随机实验...\n', r, num_runs);
            
            X = data;
            gt_orig = double(gt);
            cls_num = length(unique(gt_orig));
            num_views = length(X);
            N = size(X{1}, 2);
            
            %% 1. 数据预处理（随机排列）
            rand_index = randperm(N);
            gt_curr = gt_orig(rand_index);
            X_curr = cell(1, num_views);
            X1 = cell(1, num_views);
            
            for v = 1:num_views
                X_curr{v} = X{v}(:, rand_index); 
                X_curr{v} = NormalizeData(X_curr{v});
                X1{v} = X_curr{v}'; 
            end
            
      
            [V_base] = compute_V_base(X1, W_type, gt_curr);
            
            %% 3. 参数搜索与优化
            max_val_in_run = -1;
            best_re_in_run = [];
            best_time_in_run = 0;
            
            % 这里的 lambda 搜索逻辑保留了您原代码的结构
            base_lambda = 0.0001;
            for p = 1:9
                tic;
                lambda = base_lambda * p;
                
                [Z, E] = TLS_pNMMSC_GFT_V(X_curr, lambda, V_base);
                
                % 谱聚类
                S = 0;
                for k = 1:num_views
                    S = S + abs(Z{k}) + abs(Z{k}');
                end
                C = SpectralClustering(S, cls_num);
                t_spent = toc;
                
                result = ClusteringMeasure1(gt_curr, C) % result(1) 通常是 ACC 或 NMI
                
                if result(1) > max_val_in_run
                    max_val_in_run = result(1);
                    best_re_in_run = result;
                    best_time_in_run = t_spent;
                end
            end
            
            % 记录第 r 次随机实验的最佳结果
            run_results(r, :) = best_re_in_run;
            run_times(r) = best_time_in_run;
        end
        
        %% 4. 计算统计量 (均值与方差)
        mean_re = mean(run_results, 1);
        std_re = std(run_results, 0, 1);
        mean_time = mean(run_times);
        std_time = std(run_times);
        % 打印当前数据集的最终结果 (以第一个指标 ACC 为例)
        fprintf('  [完成] 5次平均 ACC: %.4f ± %.4f\n', mean_re(1), std_re(1));
        
        %% 5. 保存结果
        save_path = fullfile('result', strcat('Final_result_', W_type, '_', dataname(it_name), '.mat'));
        if ~exist('result', 'dir'), mkdir('result'); end
        
        save(save_path, 'run_results', 'mean_re', 'std_re', 'mean_time','run_times','std_time');
    end
end