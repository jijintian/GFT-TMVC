clc;
clear;
addpath('./');
addpath('./measure');
addpath('..\dataset_shuffle');

% Define the list of datasets
dataname = ["MSRCv1"];
num_runs = 5;

for it_name = 1:length(dataname)
    fprintf('正在处理数据集: %s\n', dataname(it_name));
    
    % 加载原始数据
    load(strcat('dataset_shuffle/Shuffle_', dataname(it_name), '.mat'));
    X_raw = data; 
    gt_raw = double(gt);
    N = size(X_raw{1}, 2);
    cls_num = length(unique(gt_raw));
    num_views = length(X_raw);

    % 初始化存储矩阵：行代表次数，列代表指标 (ClusteringMeasure1 通常返回 7 个指标)
    run_results = []; 
    run_times = zeros(num_runs, 1);
    run_paras = zeros(num_runs, 1);

    for run = 1:num_runs
        fprintf('--- 随机实验第 %d/%d 次 ---\n', run, num_runs);
        
        %% 1. 数据重新随机排列与预处理
        rand_index = randperm(N);
        gt = gt_raw(rand_index);
        X = cell(size(X_raw));
        for v = 1:num_views
            X{v} = X_raw{v}(:, rand_index);
            X{v} = NormalizeData(X{v}); % 归一化
        end

        %% 2. 调参循环 (lambda)
        max_val = 0;
        best_result_this_run = [];
        best_para_this_run = 0;
        best_time_this_run = 0;

        lambda_base = 0.0001;
        for i = 1:9
            current_lambda = lambda_base * i;
            
            tic;
            [Z, E] = TLS_pNMMSC_fft_view(X, current_lambda);

            % 谱聚类生成相似度矩阵
            S = 0;
            for k = 1:num_views
                S = S + abs(Z{k}) + abs(Z{k}');
            end
            
            C = SpectralClustering(S, cls_num);
            current_time = toc;
            
            % 计算指标 (通常 result(1) 是 ACC)
            result = ClusteringMeasure1(gt, C)
            
            % 记录该次随机排列下的最佳参数结果
            if result(1) > max_val
                max_val = result(1);
                best_result_this_run = result;
                best_para_this_run = i;
                best_time_this_run = current_time;
            end
        end
        
        % 存储这第 run 次实验的最优表现
        run_results = [run_results; best_result_this_run];
        run_times(run) = best_time_this_run;
        run_paras(run) = best_para_this_run;
    end

    %% 3. 计算统计结果
    final_mean = mean(run_results, 1);
    final_std = std(run_results, 0, 1);
    avg_time = mean(run_times);
    std_time = std(run_times);
    % 打印简要结果
        fprintf('\n数据集 %s 的 %d 次实验平均 ACC: %.4f ± %.4f\n', ...
        dataname(it_name), num_runs, final_mean(1), final_std(1));

    %% 4. 保存详细结果
    save_filename = fullfile('result', strcat('Final_fft_view_', dataname(it_name), '.mat'));
    save(save_filename, 'run_results', 'final_mean', 'final_std', 'run_times',  'avg_time','std_time');
end