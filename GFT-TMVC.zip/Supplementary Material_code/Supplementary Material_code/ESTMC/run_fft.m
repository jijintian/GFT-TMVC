
clear;
clc
addpath('..\dataset_shuffle');
addpath(genpath('./'));

dataname = ["MSRCv1"];
num_runs = 5;

for it_name = 1:length(dataname)
        
        fprintf('\nProcessing dataset: %s\n', dataname(it_name));
        
        % 加载原始数据
        load(strcat('dataset_shuffle/Shuffle_', dataname(it_name), '.mat'));
        % 备份原始数据，确保每轮 run 都是基于原始顺序重新打乱
        
        X_raw = data';
        gt_raw = gt;
        
        cls_num = length(unique(gt_raw));
        nV = length(X_raw);
        nN = length(gt_raw);
        
        all_runs_best_result = [];
        all_runs_best_time = [];
        %% ==================== 10 Runs Shuffle ===================
        for run = 1:num_runs
            fprintf('\n--- Run %d/%d ---\n', run, num_runs);
            
            % 1. 执行样本打乱 (Shuffle)
            rand_idx = randperm(nN);
            gt = gt_raw(rand_idx);
            X = cell(1, nV);
            for v = 1:nV
                X{v} = X_raw{v}(:,rand_idx); % 假设 X{v} 维度是  D*N
                [X{v}] = NormalizeData(X{v}); % 打乱后重新归一化
            end
            

            %% ========================== Parameters Setting ==========================
            result=[];
            num = 0;
            max_val=0;
            record_num = 0;
            ii=0;
            anchor=[cls_num,2*cls_num,3*cls_num,4*cls_num,5*cls_num];
            
            rank_fun = 4; % 1:Geman function,2:Lapace function, 3:l_delta function , 4:our ETR, 5:TNN
            rank_fun_name=["Geman","Lapace","l_delta","ETR","TNN"];
            
            %% ============================ Optimization ==============================
            for i_lammbda = -4:1:-1 
                for i_delta = -2:1:0
                    for i_anchor = 1:1
                        lammbda = 10^(i_lammbda);
                        delta=10^(i_delta);
                        anc = anchor(i_anchor);
                        ii=ii+1;
                        tic;
                        [y,FF,Z,B,converge_Z,converge_Z_G] = ESTMC(X,cls_num,delta,lammbda,anc,rank_fun);
                        time = toc;
                        [result(ii,:),res]=  ClusteringMeasure(gt, y);
                        if result(ii,1) > max_val
                            max_val = result(ii,1);
                            record = [lammbda,delta,anc,time];
                            record_result = result(ii,:)
                            record_c ={FF,Z,B,converge_Z,converge_Z_G};
                            record_time = time;
                        end
                    end
                end
            end
            all_runs_best_time = [all_runs_best_time; record_time];
            all_runs_best_result = [all_runs_best_result; record_result];
        end
        mean_result = mean(all_runs_best_result, 1);
        std_result = std(all_runs_best_result, 0, 1);
        mean_time = mean(all_runs_best_time);
        std_time = std(all_runs_best_time);
        
        disp('The best result of '+dataname(it_name)+', rank function:'+rank_fun_name(rank_fun))
        record_result
        save('.\result_ESTMC\result_ESTMC_'+rank_fun_name(rank_fun)+'_'+dataname(it_name),'all_runs_best_result', 'mean_result', 'std_result','mean_time','std_time')
    end
    
